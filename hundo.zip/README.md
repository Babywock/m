1. run this selfbot
2. enter your token in config.json
3. no loggers ; you can check the src
4.dont worry about ur token getting leaked it won't get leaked 
for help dm dexter
join spy for more info 
discord.gg/spyop
5. To Use It Put Ur Info In Config.json!!
 